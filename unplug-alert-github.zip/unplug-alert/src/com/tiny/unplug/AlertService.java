package com.tiny.unplug;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import java.io.File;

public class AlertService extends Service {

    private static final String CHANNEL_ID = "unplug6";
    private static final int NOTIFY_ID = 1;
    private static final long HOLD_MS = 3200;

    private static final String[] XIAOMI_SOUNDS = {
            "/system/media/audio/notifications/miui_notification.ogg",
            "/product/media/audio/notifications/miui_notification.ogg",
            "/system/product/media/audio/notifications/miui_notification.ogg",
            "/system/media/audio/notifications/MIUI_Notification.ogg",
            "/product/media/audio/notifications/MIUI_Notification.ogg",
            "/system/media/audio/ui/charging.ogg",
            "/system/media/audio/ui/ChargingStarted.ogg",
            "/system/media/audio/ui/ChargeComplete.ogg",
            "/product/media/audio/ui/charging.ogg",
            "/product/media/audio/ui/ChargingStarted.ogg",
            "/system/product/media/audio/ui/charging.ogg"
    };

    private static final long[] VIBRATE_PATTERN = {0, 800, 120, 800, 120, 1000};

    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;
    private boolean started;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (started) {
            return START_NOT_STICKY;
        }
        started = true;
        acquireWakeLock();
        startForeground(NOTIFY_ID, buildNotification());
        vibrate();
        playSound();
        new Handler(Looper.getMainLooper()).postDelayed(this::stopAlert, HOLD_MS);
        return START_NOT_STICKY;
    }

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm == null) {
            return;
        }
        int type = PowerManager.PARTIAL_WAKE_LOCK;
        if (Build.VERSION.SDK_INT < 27) {
            type = PowerManager.FULL_WAKE_LOCK
                    | PowerManager.ACQUIRE_CAUSES_WAKEUP
                    | PowerManager.ON_AFTER_RELEASE;
        }
        wakeLock = pm.newWakeLock(type, "unplug:alert");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire(HOLD_MS + 1500);
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, getString(R.string.alert_title), NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            ch.setVibrationPattern(VIBRATE_PATTERN);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) {
            piFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, piFlags);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(getString(R.string.alert_title))
                .setContentText(getString(R.string.alert_text))
                .setStyle(new Notification.BigTextStyle().bigText(getString(R.string.alert_text)))
                .setAutoCancel(true)
                .setOngoing(false)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setDefaults(Notification.DEFAULT_VIBRATE)
                .setVibrate(VIBRATE_PATTERN)
                .setPriority(Notification.PRIORITY_HIGH)
                .setFullScreenIntent(pi, true);
        return b.build();
    }

    private void playSound() {
        for (String path : XIAOMI_SOUNDS) {
            if (new File(path).isFile() && startPlayer(path, null)) {
                return;
            }
        }
        Uri def = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (def != null) {
            startPlayer(null, def);
        }
    }

    private boolean startPlayer(String path, Uri uri) {
        MediaPlayer mp = new MediaPlayer();
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                mp.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setLegacyStreamType(AudioManager.STREAM_ALARM)
                        .build());
            } else {
                mp.setAudioStreamType(AudioManager.STREAM_ALARM);
            }
            if (path != null) {
                mp.setDataSource(path);
            } else {
                mp.setDataSource(this, uri);
            }
            mp.setVolume(1f, 1f);
            mp.setLooping(true);
            mp.prepare();
            mp.start();
            player = mp;
            return true;
        } catch (Exception e) {
            mp.release();
            return false;
        }
    }

    private void vibrate() {
        Vibrator v;
        if (Build.VERSION.SDK_INT >= 31) {
            VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            v = vm == null ? null : vm.getDefaultVibrator();
        } else {
            v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
        if (v == null || !v.hasVibrator()) {
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(VIBRATE_PATTERN, -1));
            } else {
                v.vibrate(VIBRATE_PATTERN, -1);
            }
        } catch (Throwable ignored) {
            try {
                v.vibrate(900);
            } catch (Throwable ignored2) {
            }
        }
    }

    private void stopAlert() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            player.release();
            player = null;
        }
        stopForeground(false);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            player.release();
            player = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
