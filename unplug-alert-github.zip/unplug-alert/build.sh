#!/bin/bash
set -euo pipefail

SDK="${ANDROID_SDK_ROOT:-/opt/android-sdk}"
BT="$SDK/build-tools/34.0.0"
PLAT="$SDK/platforms/android-34/android.jar"
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/out"
GEN="$OUT/gen"
OBJ="$OUT/obj"
RES_FLAT="$OUT/res-flat"

rm -rf "$OUT"
mkdir -p "$GEN" "$OBJ" "$RES_FLAT"

AAPT2="$BT/aapt2"
D8="$BT/d8"
ZIPALIGN="$BT/zipalign"
APKSIGNER="$BT/apksigner"

"$AAPT2" compile --dir "$ROOT/res" -o "$RES_FLAT"

"$AAPT2" link \
  -o "$OUT/unsigned.apk" \
  -I "$PLAT" \
  --manifest "$ROOT/AndroidManifest.xml" \
  --java "$GEN" \
  --min-sdk-version 21 \
  --target-sdk-version 34 \
  --auto-add-overlay \
  "$RES_FLAT"/*.flat

find "$ROOT/src" "$GEN" -name '*.java' > "$OUT/sources.txt"

javac \
  --release 8 \
  -classpath "$PLAT" \
  -d "$OBJ" \
  @"$OUT/sources.txt"

"$D8" \
  --release \
  --min-api 21 \
  --lib "$PLAT" \
  --output "$OUT" \
  $(find "$OBJ" -name '*.class')

# inject classes.dex into apk (apk is a zip)
cd "$OUT"
zip -qj unsigned.apk classes.dex

"$ZIPALIGN" -f -p 4 unsigned.apk aligned.apk

if [ ! -f "$ROOT/debug.keystore" ]; then
  keytool -genkeypair -v \
    -keystore "$ROOT/debug.keystore" \
    -storepass android \
    -keypass android \
    -alias androiddebugkey \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -dname "CN=Unplug Alert, O=Tiny, C=CN"
fi

"$APKSIGNER" sign \
  --ks "$ROOT/debug.keystore" \
  --ks-pass pass:android \
  --key-pass pass:android \
  --ks-key-alias androiddebugkey \
  --out "$ROOT/unplug-alert.apk" \
  aligned.apk

"$APKSIGNER" verify --verbose "$ROOT/unplug-alert.apk"
ls -lh "$ROOT/unplug-alert.apk"
