# 拔掉充电器

打开即播提示音、震动，并弹出通知：

> 电量已经95%，请拔掉充电器。

震动结束后自动退出。无界面、无后台服务。

## 安装

把 `unplug-alert.apk` 拷到手机后安装。

- 系统要求：Android 5.0 及以上
- Android 13 及以上：首次打开会申请通知权限，允许后才会弹出通知栏
- 安装来源：需允许“未知来源 / 安装未知应用”

## 重新编译

```bash
export ANDROID_SDK_ROOT=/opt/android-sdk
./build.sh
```

生成文件：`unplug-alert.apk`（约 13KB）
